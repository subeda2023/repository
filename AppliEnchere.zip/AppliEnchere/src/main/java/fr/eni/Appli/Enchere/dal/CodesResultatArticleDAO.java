package fr.eni.Appli.Enchere.dal;

public class CodesResultatArticleDAO {

	public CodesResultatArticleDAO() {
		// Echec quand tentative d'insertion d'un article null
		public static final int INSER_OBJET_NULL=10000;
	}

}
