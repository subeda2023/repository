package fr.eni.Appli.Enchere.bll.bo;

public class AppliTestBO {

	public AppliTestBO() {
		// TODO Auto-generated constructor stub
	}

}
