package fr.eni.Appli.Enchere.dal;

public class ArticleDAOJdbcImpl {

	public ArticleDAOJdbcImpl() {
		// TODO Auto-generated constructor stub
	}

}
