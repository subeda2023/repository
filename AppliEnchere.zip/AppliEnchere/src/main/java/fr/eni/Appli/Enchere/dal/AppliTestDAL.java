package fr.eni.Appli.Enchere.dal;

public class AppliTestDAL {

	public AppliTestDAL() {
		
	}
	
	
	
		public static void main(String[]args) {
			
		}

}
