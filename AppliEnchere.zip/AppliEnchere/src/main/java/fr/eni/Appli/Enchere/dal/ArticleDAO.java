package fr.eni.Appli.Enchere.dal;

public class ArticleDAO {
	
	private static final String INSERT_ARTICLE ="INSERT into articles_vendus(nom_article, description, date_debut_encheres, date_fin_encheres, prix_ initial) values(?,?,?,?,?)";

	public ArticleDAO() {
		public void insert(ArticleVendu article) {
			if(article ==null) {
				BusinessException businessException = new BusinessException();
				businessException.ajouterErreur()
			}
			
		}
	}

}
